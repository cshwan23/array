import UIKit

// mutable array
var emptyArray = Array<String>()
var emptyArray2 = [String]()

print(emptyArray2)

emptyArray2.append("승환")
emptyArray2.append("스위프트")

print(emptyArray2)

var emptyArray3 = ["승환","스위프트","맥북"]

print(emptyArray3)

emptyArray3 += ["Choi"]
emptyArray3 += ["Seung"]
emptyArray3 += ["Hwan"]

print(emptyArray3)

print(emptyArray3[3])
// 0 1 2 3 임.
//연산자 ... 연산자
//값을 바꾸려면
emptyArray3[3] = "Hi"
print(emptyArray3)

//여러가지 바꾸려면 ... 연산자
emptyArray3[3...5] = ["A","B","C"]
print(emptyArray3)
print(emptyArray3.count)

// 여기까지는 가변 배열 var.

// let 으로 만들어 보자
// immutable array

let emptyArray4 = ["승환","스위프트","맥북"]
//emptyArray4[2] = "hello" 이렇게 만들면 오류가 뜬다 let 이라 바꿀수 없다.

print(emptyArray4)

